module FinalProjectGroup9 {
	requires java.sql;
	requires javafx.base;
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires mysql.connector.java;
	opens sample to javafx.graphics, javafx.fxml, javafx.base;
}




