package sample;

public class Author {
	private String aName;
	private long authorID;

	public Author(String firstName, Long author_ID) {
		super();
		aName = firstName;
		authorID = author_ID;

	}

	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getaName() {
		return aName;
	}

	public void setaName(String aName) {
		this.aName = aName;
	}

	public long getAuthorID() {
		return authorID;
	}

	public void setAuthorID(long authorID) {
		this.authorID = authorID;
	}
}
