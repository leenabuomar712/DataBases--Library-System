package sample;

public class Book {

	private int bID;
	private String bName;
	private String bAuthor;
	private int bPrice;
	private String category;
	/*
	 * public Book(int bID, String bName, int bPrice, int YearOfProduction, String
	 * bAuthor, String category) { this.bID = bID; this.bName = bName; this.bPrice =
	 * bPrice; this.YearOfProduction = YearOfProduction; this.bAuthor = bAuthor;
	 * this.category = category; }
	 */

	public Book(int ISBN, String title, String author, int Price, String Category) {
		bID = ISBN;
		bName = title;
		bAuthor = author;
		bPrice = Price;
		category = Category;

	}

	public Book() {
		super();
	}

	public int getbID() {
		return bID;
	}

	public void setbID(int bID) {
		this.bID = bID;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getbName() {
		return bName;
	}

	public void setbName(String bName) {
		this.bName = bName;
	}

	public String getbAuthor() {
		return bAuthor;
	}

	public void setbAuthor(String bAuthor) {
		this.bAuthor = bAuthor;
	}

	public int getbPrice() {
		return bPrice;
	}

	public void setbPrice(int bPrice) {
		this.bPrice = bPrice;
	}
}