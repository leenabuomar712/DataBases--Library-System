package sample;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.mysql.jdbc.PreparedStatement;

import sample.Book;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

public class BooksManagmentSystemController {

	private ArrayList<Book> BookData;
	private ObservableList<Book> dataListBook;

	@FXML
	private TableColumn<Author, String> AuthorName;

	@FXML
	private TableColumn<Book, Integer> BookID;

	@FXML
	private TableColumn<Book, String> BookName;

	@FXML
	private TableColumn<Book, Integer> BookPrice;

	@FXML
	private TableColumn<Book, String> Category;

	@FXML
	private TableView<Book> TableView;

	@FXML
	private Button addBook;

	@FXML
	private Button back;

	@FXML
	private Button delBook;

	@FXML
	private Button editBook;
	@FXML
	private Button econfirm;
	@FXML
	private TextField book_search;
	@FXML
	private TextField tfAuthor;

	@FXML
	private TextField tfCategory;

	@FXML
	private TextField tfPrice;

	@FXML
	private TextField tfTitle;

	@FXML
	private TextField tfYear;

	@FXML
	private TextField tfbookId;

	@FXML
	void AddBook(ActionEvent event) throws IOException {
		// showStage("AddBook");
		if (BookName.getText().isEmpty() || BookID.getText().isEmpty() || AuthorName.getText().isEmpty()
				|| BookPrice.getText().isEmpty() || Category.getText().isEmpty()) {
			System.out.println("Error !!, You must fill all fields !!");
		}

		if (!isNumeric(BookID.getText()) || !isNumeric(BookPrice.getText())) {
			System.out.println("Error !!, Book ID and Price must be a Number !!");
			return;
		}

		Book bo = new Book(Integer.parseInt(BookID.getText()), BookName.getText(), AuthorName.getText(),
				Integer.parseInt(BookPrice.getText()), Category.getText());

		try {

			Connector.a.connectDB();
			String sql = "Insert into book (bID, bName, bAuthor,bPrice, category)" + " values(?,?,?,?,?)";
			PreparedStatement ps = (PreparedStatement) Connector.a.connectDB().prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(BookID.getText()));
			ps.setString(2, BookName.getText());
			ps.setString(3, AuthorName.getText());
			ps.setInt(4, Integer.parseInt(BookPrice.getText()));
			ps.setString(5, Category.getText());
			ps.execute();

		} catch (SQLException er) {
			er.printStackTrace();
		} catch (ClassNotFoundException er) {
			er.printStackTrace();
		}
	}

	@FXML
	public void initialize() {
		BookData = new ArrayList<>();
		dataListBook = FXCollections.observableArrayList(BookData);
		TableView.setEditable(true);
		BookID.setCellValueFactory(new PropertyValueFactory<Book, Integer>("bID"));
		BookName.setCellValueFactory(new PropertyValueFactory<Book, String>("bName"));
		AuthorName.setCellValueFactory(new PropertyValueFactory<Author, String>("bAuthor"));
		BookPrice.setCellValueFactory(new PropertyValueFactory<Book, Integer>("bPrice"));
		Category.setCellValueFactory(new PropertyValueFactory<Book, String>("category"));
		getBookData();
		TableView.setItems(dataListBook);
		bookSearch2();
	}

	public void getBookData() {
		String SQL = "select * from Book";
		try {
			Connector.a.connectDB();
			java.sql.Statement state = Connector.a.connectDB().createStatement();
			ResultSet dataSql = state.executeQuery(SQL);
			while (dataSql.next()) {

				Book b = new Book(dataSql.getInt(1), dataSql.getString(2), dataSql.getString(3), dataSql.getInt(4), dataSql.getString(5));
				 dataListBook.add(b);
			}
			dataSql.close();
			state.close();
			Connector.a.connectDB().close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	void DeleteBook(ActionEvent event) {
		try {
			Connector.a.connectDB();
			Connector.a.ExecuteStatement("delete from  Book where bId =" + Integer.parseInt(BookID.getText()) + ";");
			Connector.a.connectDB().close();
			System.out.println("Connection closed");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void EditBook(ActionEvent event) {
		try {
			Connector.a.connectDB();

			Connector.a.ExecuteStatement("update Book set bName  = " + BookName.getText() + " where bID = "
					+ Integer.parseInt(BookID.getText()) + ";");

			Connector.a.ExecuteStatement("update Book set bAuthor = " + AuthorName.getText() + " where bID = "
					+ Integer.parseInt(BookID.getText()) + ";");

			Connector.a.ExecuteStatement("update Book set bPrice  = " + BookPrice.getText() + " where bID = "
					+ Integer.parseInt(BookID.getText()) + ";");
			Connector.a.ExecuteStatement("update Book set category = " + Category.getText() + "where bID = "
					+ Integer.parseInt(BookID.getText()) + ";");
			Connector.a.connectDB().close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void back(ActionEvent event) throws IOException {
		showStage("Menu");

	}

	void bookSearch2() {
		FilteredList<Book> filteredData = new FilteredList<>(dataListBook, b -> true);
		book_search.textProperty().addListener((observable, oldValue, newValue) -> {
			filteredData.setPredicate(Book -> {
				if (newValue == null || newValue.isEmpty()) {
					return true;
				}
				String lowerCaseFilter = newValue.toLowerCase();

				if (Book.getbName().toLowerCase().indexOf(lowerCaseFilter) != -1) {
					return true;
				} else
					return false;
			});
		});

		SortedList<Book> sortedData = new SortedList<>(filteredData);
		sortedData.comparatorProperty().bind(TableView.comparatorProperty());
		TableView.setItems(sortedData);
	}

	@FXML
	void bookSearch(ActionEvent event) {

	}

	public void showStage(String ClassXmlName) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource(ClassXmlName.concat(".fxml")));
		Main.stage.setScene(new Scene(root));
		Main.stage.centerOnScreen();
		Main.stage.show();
	}

	public boolean isNumeric(String str) {
		try {
			Long.parseLong(str);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

}
