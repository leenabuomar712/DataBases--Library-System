package sample;


import java.util.Date;

public class Borrow {
    private int bookID;
    private int customerID;
    private Date BorrowDate;
    private Date RetDate;

    public Borrow(int bID, int cID, Date borrowDate, Date retDate) {
        super();
        bookID = bID;
        customerID = cID;
        BorrowDate = borrowDate;
        RetDate = retDate;
    }

    public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public Date getBorrowDate() {
        return BorrowDate;
    }

    public void setBorrowDate(Date borrowDate) {
        BorrowDate = borrowDate;
    }

    public int getSID() {
        return bookID;
    }

    public void setSID(int sID) {
        bookID = sID;
    }

    public Date getRetDate() {
        return RetDate;
    }

    public void setRetDate(Date retDate) {
        RetDate = retDate;
    }

}
