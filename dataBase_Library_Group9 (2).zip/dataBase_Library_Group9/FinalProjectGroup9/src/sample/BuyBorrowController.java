package sample;



import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;

public class BuyBorrowController implements Initializable {
    private Connection con;

    private ArrayList<Book> data;

    static ObservableList<Book> dataList = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Book, String> AuthorName;

    @FXML
    private TableColumn<Book, Integer> BookID;

    @FXML
    private TableColumn<Book, String> BookName;

    @FXML
    private TableColumn<Book, Integer> BookPrice;

    @FXML
    private TableColumn<Book, String> Category;

    @FXML
    private TableView<Book> TableView;

    @FXML
    private ComboBox<String> ComboBoxBook;

    @FXML
    void bookSearch(ActionEvent event) {

    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {

    	ComboBoxBook.getItems().removeAll(ComboBoxBook.getItems());
    	ComboBoxBook.getItems().addAll("Buy", "Borrow");
    	ComboBoxBook.getSelectionModel().select("Buy");
 
    	
    	
      /*  try {
            AuthorName.setCellValueFactory(new PropertyValueFactory<Book, String>("bAuthor"));
            BookID.setCellValueFactory(new PropertyValueFactory<Book, Integer>("bId"));
            BookName.setCellValueFactory(new PropertyValueFactory<Book, String>("bName"));
            BookPrice.setCellValueFactory(new PropertyValueFactory<Book, Integer>("bPrice"));
            Category.setCellValueFactory(new PropertyValueFactory<Book, String>("category"));

            data.clear();


            getBook();
            TableView.setItems((ObservableList<sample.Book>) data);
            TableView.setEditable(true);
            TableView.setStyle("-fx-table-cell-border-color: transparent;");
//combo boxes
            //     cbSearch.getItems().addAll("ISBN", "Title", "Author", "Edition", "Publisher", "Section", "Year", "Country");
            //    cbSearch.setPromptText("Choose Category");

	            AuthorName.setCellFactory(TextFieldTableCell.forTableColumn());
	            BookID.setCellValueFactory(TextFieldTableCell.forTableColumn());
	            BookName.setCellFactory(TextFieldTableCell.<Book, Integer>forTableColumn(new IntegerStringConverter()));
	            BookPrice.setCellFactory(TextFieldTableCell.forTableColumn());
	            Category.setCellValueFactory(TextFieldTableCell.<Book, Integer>forTableColumn(new IntegerStringConverter()));
	        */
            TableView.refresh();

   // catch (NullPointerException ex) }
    }

    @FXML
    void bookCombo(ActionEvent event) {

    }
    public void db() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/library?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
                    "root", "root");
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public void alert(AlertType type, String title, String text) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
        stage.getIcons().add(new Image("images/icon.png"));
        alert.setContentText(text);
        alert.showAndWait();
    }



    public void getBook() {
        try {
            Statement s = null;
            ResultSet rs = null;
            ResultSet rs2 = null;
            Statement s2 = null;
            db();
            s = con.createStatement();
            s2 = con.createStatement();
            rs = s.executeQuery("select * from book;");
            while (rs.next()) {
                rs2 = s2.executeQuery("select * from author where bID" + rs.getInt(2));
                // data.add(new Book(rs.getInt(0), rs.getString(1), rs.getString(2,
                // rs.getInt(3), rs.getString(4))));

            }
            con.close();

        } catch (Exception ex) {
            System.out.println(ex);

        }
    }

}
