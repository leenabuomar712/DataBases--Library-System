package sample;

public class Classification {
	private String Type;
	private int ClassificationID;

	public Classification(int cID, String type) {
		super();
		ClassificationID = cID;
		Type = type;

	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public int getClassificationID() {
		return ClassificationID;
	}

	public void setClassificationID(int classificationID) {
		ClassificationID = classificationID;
	}

}
