package sample;

import java.io.IOException;

import sample.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

public class Controller {

    @FXML
    private Button customerB;

    @FXML
    private Button eButton;
    @FXML
    void btnCustomerOnAction(ActionEvent event) throws IOException {
    	showStage("BuyBorrow");

    }

    @FXML
    void btnEmployeeOnAction(ActionEvent event) throws IOException{
    	showStage("Login");
    }
	public void showStage(String ClassXmlName) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource(ClassXmlName.concat(".fxml")));
		Main.stage.setScene(new Scene(root));
		Main.stage.centerOnScreen();
		Main.stage.show();
	}
}
