package sample;

public class Customer {
	private String customerName;
	private Long customerPhone;
	private String customerAddress;
	private Long customerID;

	public Customer(String cName, Long cPhone, String cAddress, Long cID) {
		super();
		customerName = cName;
		customerPhone = cPhone;
		customerAddress = cAddress;
		customerID = cID;

	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Long getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(Long customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public Long getCustomerID() {
		return customerID;
	}

	public void setCustomerID(Long customerID) {
		this.customerID = customerID;
	}
}
