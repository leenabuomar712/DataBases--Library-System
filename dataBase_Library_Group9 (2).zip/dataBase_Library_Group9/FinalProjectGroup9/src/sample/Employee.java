package sample;

public class Employee {
	private String employeeName;
	private int employeeId;
	private int employeePhone;
	private String employeeDepartment;
	private String pass;
	public Employee() {
		super();
	}
	public Employee(String employeeName, int employeeId, int employeePhone, String employeeDepartment, String pass) {
		super();
		this.employeeName = employeeName;
		this.employeeId = employeeId;
		this.employeePhone = employeePhone;
		this.employeeDepartment = employeeDepartment;
		this.pass = pass;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getEmployeePhone() {
		return employeePhone;
	}
	public void setEmployeePhone(int employeePhone) {
		this.employeePhone = employeePhone;
	}
	public String getEmployeeDepartment() {
		return employeeDepartment;
	}
	public void setEmployeeDepartment(String employeeDepartment) {
		this.employeeDepartment = employeeDepartment;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}

	

}
