package sample;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ResourceBundle;

import com.mysql.jdbc.PreparedStatement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

public class EmployeeManagerController {
	@FXML
	private TableView<Employee> TableData;
	private ArrayList<Employee> EmpData;
	private ObservableList<Employee> dataList;
	
	
	@FXML
    private TextField empDe;

    @FXML
    private TextField empNm;

    @FXML
    private TextField empPh;

  
    @FXML
    private TextField empid;
    @FXML
    private TextField empPass;
    
	
	@FXML
	private TextField tfPhone;

	@FXML
	private TextField tfeDep;

	@FXML
	private TextField tfeID;

	@FXML
	private TextField tfeName;
	@FXML
	private TextField employee_search;
	@FXML
	private TableColumn<Employee, Integer> empID;
	@FXML
	private TableColumn<Employee, String> empName;

	@FXML
	private TableColumn<Employee, Integer> empPhone;

	@FXML
	private TableColumn<Employee, String> empDepartment;

	@FXML
	private Button addEmp;

	@FXML
	private Button delEp;
	@FXML
	private TextField pass;

	@FXML
	private Button EditEmp;

	@FXML
	private Button back;
	@FXML
	private Button econfirm;

	@FXML
	public void initialize() {
		EmpData = new ArrayList<>();
		dataList = FXCollections.observableArrayList(EmpData);
		TableData.setEditable(true);
		empID.setCellValueFactory(new PropertyValueFactory<Employee, Integer>("employeeId"));
		empName.setCellValueFactory(new PropertyValueFactory<Employee, String>("employeeName"));
		empPhone.setCellValueFactory(new PropertyValueFactory<Employee, Integer>("employeePhone"));
		empDepartment.setCellValueFactory(new PropertyValueFactory<Employee, String>("employeeDepartment"));
		getEmpData();
		TableData.setItems(dataList);
		empSearch();
	}

	void empSearch() {
		FilteredList<Employee> filteredData = new FilteredList<>(dataList, b -> true);
		employee_search.textProperty().addListener((observable, oldValue, newValue) -> {
			filteredData.setPredicate(Employee -> {
				if (newValue == null || newValue.isEmpty()) {
					return true;
				}
				String lowerCaseFilter = newValue.toLowerCase();

				if (Employee.getEmployeeName().toLowerCase().indexOf(lowerCaseFilter) != -1) {
					return true; 
				} else
					return false; 
			});
		});
		SortedList<Employee> sortedData = new SortedList<>(filteredData);
		sortedData.comparatorProperty().bind(TableData.comparatorProperty());
		TableData.setItems(sortedData);
	}
	@FXML
	void EmployeeSearch(ActionEvent event) {
		
	}

	public void getEmpData() {
		String SQL = "select * from employee";
		try {
			Connector.a.connectDB();
			java.sql.Statement state = Connector.a.connectDB().createStatement();
			ResultSet dataSql = state.executeQuery(SQL);
			while (dataSql.next()) {
				Employee em = new Employee(dataSql.getString(2),dataSql.getInt(1),Integer.parseInt(dataSql.getString(3)),dataSql.getString(4),dataSql.getString(5));
				dataList.add(em);
			}
			dataSql.close();
			state.close();
			Connector.a.connectDB().close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

//	@FXML
//	void AddEmployee(ActionEvent event) throws IOException {
//
//		showStage("AddEmployee");
//
//	}

	@FXML
	void AddEmployee(ActionEvent event) throws IOException {

		if (empNm.getText().isEmpty() || empid.getText().isEmpty() || empPh.getText().isEmpty()
				|| empDe.getText().isEmpty()) {
			System.out.println("Error !!, You must fill all fields !!");
		}

		if (!isNumeric(empid.getText())) {
			System.out.println("Error !!, Employee ID must be a Number !!");
			return;
		}

		Employee e = new Employee(empNm.getText(), Integer.parseInt(empid.getText()),
				Integer.parseInt(empPh.getText()), empDe.getText(), "root");

		try {

			Connector.a.connectDB();
			String sql = "Insert into employee (eId, eName, ePhone,eDepartment,ePassword)" + " values(?,?,?,?,?)";
			PreparedStatement ps = (PreparedStatement) Connector.a.connectDB().prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(empid.getText()));
			ps.setString(2, empNm.getText());
			ps.setString(3, empPh.getText());
			ps.setString(4, empDe.getText());
			ps.setString(5, "root");
			ps.execute();

		} catch (SQLException er) {
			er.printStackTrace();
		} catch (ClassNotFoundException er) {
			er.printStackTrace();
		}

//		econfirm.setVisible(false);

	}

	@FXML
	void DeleteEmployee(ActionEvent event) {
		try {
			Connector.a.connectDB();
			Connector.a.ExecuteStatement("delete from  employee where eId =" + Integer.parseInt(empid.getText()) + ";");
			Connector.a.connectDB().close();
			System.out.println("Connection closed");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void EditEmployee(ActionEvent event) {

		try {
			Connector.a.connectDB();
	
			Connector.a.ExecuteStatement(
					"update employee set eName  = " + empNm.getText() + " where eId = " + Integer.parseInt(empid.getText()) + ";");
			Connector.a.ExecuteStatement(
					"update employee set ePhone  = " + empPh.getText() + " where eId = " + Integer.parseInt(empid.getText()) + ";");
			Connector.a.ExecuteStatement(
					"update employee set eDepartment  = " + empDe.getText() + " where eId = " + Integer.parseInt(empid.getText()) + ";");
			Connector.a.connectDB().close();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	@FXML
	void back(ActionEvent event) throws IOException {

		showStage("Menu");
	}

	@FXML
	private Button ee_back;

	@FXML
	void BackFromEmployeeRegestrationPage(ActionEvent event) throws IOException {
		showStage("EmployeeManager");
	}
	public void showStage(String ClassXmlName) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource(ClassXmlName.concat(".fxml")));
		Main.stage.setScene(new Scene(root));
		Main.stage.centerOnScreen();
		Main.stage.show();
	}

	public boolean isNumeric(String str) {
		try {
			Long.parseLong(str);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
}
