package sample;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class LoginController {

	private Stage stage;
	private Scene scene;
	private Parent root;
	@FXML
	private Button login;
	@FXML
	private Button login_back;
	@FXML
	private TextField pass;
	@FXML
	private Button b_login;
	@FXML
	private TextField username;

	@FXML
	void log(ActionEvent event) {

		try {
			PreparedStatement st = Connector.a.connectDB()
					.prepareStatement("select * from employee where eName = ? AND ePassword = ? ");
			st.setString(1, username.getText());
			st.setString(2, pass.getText());
			ResultSet r1 = st.executeQuery();
			if (username.getText().equals("") || pass.getText().equals("")) {

				showDialog("error", "you entered a wrong data", null, AlertType.ERROR);
				return;

			}

			else {
				if (r1.next()) {
					if (r1.getString(2).toLowerCase().equals(username.getText().toLowerCase())
							&& (r1.getString(5).toLowerCase().equals(pass.getText().toLowerCase()))) {

						try { // open new stage

							stage = (Stage) login.getScene().getWindow();
							stage.close();
							root = FXMLLoader.load(getClass().getResource("/view/menu.fxml"));
							scene = new Scene(root, 600, 588);
							stage.setScene(scene);
							stage.setTitle("Admin Page");
							stage.show();

						} catch (IOException e1) {

							showDialog("error", "you entered a wrong data", null, AlertType.ERROR);
						}
					}

				} else {
					showDialog("error", "you entered a wrong data", null, AlertType.ERROR);
					return;
				}

			}
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

	@FXML
	void initialize() {

	}

	@FXML
	void LogInBack(ActionEvent event) throws IOException {
		showStage("sample");

	}

	public void showDialog(String title, String header, String body, AlertType type) {
		Alert alert = new Alert(type);
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(body);

		alert.show();

	}

	private void showStage(String ClassXmlName) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource(ClassXmlName.concat(".fxml")));
		Main.stage.setScene(new Scene(root));
		Main.stage.centerOnScreen();
		Main.stage.show();

	}

}

/*
 * import java.io.IOException; import java.sql.PreparedStatement; import
 * java.sql.ResultSet; import java.sql.SQLException; import java.sql.*;
 * 
 * import javafx.event.ActionEvent; import javafx.fxml.FXML; import
 * javafx.fxml.FXMLLoader; import javafx.scene.Parent; import
 * javafx.scene.Scene; import javafx.scene.control.Alert; import
 * javafx.scene.control.Button; import javafx.scene.control.TextField; import
 * javafx.scene.control.Alert.AlertType; import javafx.stage.Stage;
 * 
 * public class LoginController {
 * 
 * private Stage stage; private Scene scene; private Parent root;
 * 
 * @FXML private Button login;
 * 
 * 
 * 
 * @FXML private Button login_back;
 * 
 * @FXML void LogInBack(ActionEvent event) throws IOException {
 * showStage("sample"); }
 * 
 * @FXML void log(ActionEvent event) throws IOException { showStage("Menu");
 * 
 * 
 * 
 * } private void showStage(String ClassXmlName) throws IOException {
 * 
 * Parent root =
 * FXMLLoader.load(getClass().getResource(ClassXmlName.concat(".fxml")));
 * Main.stage.setScene(new Scene(root)); Main.stage.centerOnScreen();
 * Main.stage.show();
 * 
 * }
 * 
 * @FXML void initialize() {
 * 
 * 
 * }
 * 
 * 
 * public void showDialog(String title, String header, String body, AlertType
 * type) { Alert alert = new Alert(type); alert.setTitle(title);
 * alert.setHeaderText(header); alert.setContentText(body);
 * 
 * alert.show();
 * 
 * }
 * 
 * 
 * 
 * }
 */
