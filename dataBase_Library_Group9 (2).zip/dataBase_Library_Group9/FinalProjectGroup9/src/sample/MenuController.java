package sample;



import java.io.IOException;


//
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;


public class MenuController {


    @FXML
    private Button employee;

    @FXML
    private Button books;
    @FXML
    private Button customer_Views;
    @FXML
    private Button logout;


    @FXML
    void employee_page(ActionEvent event) throws IOException {

        showStage("EmployeeManager");

    }
    @FXML
    void CustomerViews(ActionEvent event) throws IOException {

        showStage("Customer");

    }
    @FXML
    void LogOUT(ActionEvent event) throws IOException {

        showStage("login");

    }
    private void showStage(String ClassXmlName) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource(ClassXmlName.concat(".fxml")));
        Main.stage.setScene(new Scene(root));
        Main.stage.centerOnScreen();
        Main.stage.show();

    }
    @FXML
    void BooksPage(ActionEvent event) throws IOException {

    	 showStage("ManagerBookView");


    }

}
