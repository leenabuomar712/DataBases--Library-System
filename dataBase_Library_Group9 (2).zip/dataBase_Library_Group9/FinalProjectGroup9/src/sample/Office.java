package sample;

public class Office {
	private String OfficeName;
	private int OfficeID;

	public Office(int offID, String offName) {
		super();
		OfficeID = offID;
		OfficeName = offName;

	}

	public String getOfficeName() {
		return OfficeName;
	}

	public void setOfficeName(String officeName) {
		OfficeName = officeName;
	}

	public int getOfficeID() {
		return OfficeID;
	}

	public void setOfficeID(int officeID) {
		OfficeID = officeID;
	}

}
