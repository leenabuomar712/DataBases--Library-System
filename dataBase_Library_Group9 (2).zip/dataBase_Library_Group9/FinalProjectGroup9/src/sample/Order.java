package sample;


public class Order {
	private int OrderID;
	private int OrderLineID;
	private int TotalPrice;

	public Order(int orderID, int orderLineID, int price) {
		super();
		OrderID = orderID;
		OrderLineID = orderLineID;
		TotalPrice = price;

	}

	public int getOrderID() {
		return OrderID;
	}

	public void setOrderID(int orderID) {
		OrderID = orderID;
	}

	public int getOrderLineID() {
		return OrderLineID;
	}

	public void setOrderLineID(int orderLineID) {
		OrderLineID = orderLineID;
	}

	public int getTotalPrice() {
		return TotalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		TotalPrice = totalPrice;
	}

}
