package sample;

public class OrderLine {

	private long OrderLineID;
	private long bID;
	private int Quantity;

	public OrderLine(Long OL_ID, Long bookID, int quantity) {
		super();
		OrderLineID = OL_ID;
		bID = bookID;
		Quantity = quantity;

	}

	public long getOrderLineID() {
		return OrderLineID;
	}

	public void setOrderLineID(long orderLineID) {
		OrderLineID = orderLineID;
	}

	public long getbID() {
		return bID;
	}

	public void setbID(long bID) {
		this.bID = bID;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
}
