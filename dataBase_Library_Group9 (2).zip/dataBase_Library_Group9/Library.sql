drop database library;
Create database library;
SHOW TABLES;
use library;

Create table Author(aID int, 
	aName varchar(45), 
    primary key(aID));
select * from Author;    

create table Book(bID int, 
    bName varchar(45),
    bAuthor varchar(45),
    bPrice int,
    YearOfProduction int,
    category varchar(45),
    primary key(bID));
select * from Book;    

create table classification(cID int,
    cType varchar(45),
    primary key(cID));
select * from classification;

create table orderLine(orederLine_ID int, 
    bID int,
    quantity int,
    primary key(orederLine_ID, bID),
    foreign key(bID) references Book(bID));
select * from orderLine;

create table customer(customerID int,
    cPhone int,
    cAddress varchar(45),
    cName varchar(45),
    primary key(customerID));
select * from customer;  
 
 CREATE TABLE Subscribtion(
	Amount real,
    SubDate date,
    customerID int,
	foreign key (customerID) references customer(customerID) on delete cascade
);
select * from Subscribtion; 
create table orders(orders_ID int,
    customerID int,
    totalPrice int,
    primary key(orders_ID, customerID),
    foreign key(customerID)references customer(customerID));
select * from orders;    

create table office(oNumber int,
    oName varchar(45),
    primary key(oNumber));
select * from office;    

CREATE TABLE Borrow(
	B_Date date not Null,
	Ret_Date date,
	bID int,
    customerID int,
    foreign key (bID) references Book(bID),
    foreign key (customerID) references customer(customerID),
	PRIMARY KEY (bID, customerID)
);
select * from Borrow;
create table employee(eId int, 
    eName varchar(45),
    ePassword varchar(45),
    ePhone varchar(45),
    eDepartment varchar(45),
    ePassword varchar(45),
    primary key(eID));
select * from employee;    

insert into Author(aID, aName) values 
(0, 'Dustin'),
(1, 'Lubber'),
(2, 'Rusty'),
(3, 'Andy'),
(4, 'Tala');

insert into Book(bID, bName, bAuthor, bPrice) values 
(77, 'The Dark Road', 'Dustin', 87),
(32, 'Harry Potter', 'Andy', 20),
(12, 'Strangers', 'Rusty', 34);

insert into classification(cID, cType) values
(11, 'History'),
(12, 'Geography'),
(13, 'medicine'),
(14, 'Science');

insert into orderLine(orderLine_ID, bID, quantity) values
(24, 32, 2),
(25, 12, 4),
(26, 77, 1);

insert into customer(customerID, cPhone, cAddress, cName) values
(55, 059855481, 'Ramallah', 'Leen'),
(56, 059842481, 'Al-Quds', 'Noor'),
(57, 059855761, 'Hebron', 'Yazan');

insert into orders(orders_ID, customerID, totalPrice) values 
(4, 55, 81),
(5, 56, 73),
(6, 57, 25);

insert into office(oNumber, oName) values
(44, 'employees office'),
(45, 'manager office'),
(46, 'customer office');

insert into employee(eId, eName, ePhone, eDepartment) value
(100, 'Amer', 059866761, 'manager'),
(101, 'Ahmad', 059855105, 'employee'),
(102, 'Osaid', 059859331, 'employee');
