create database project1;

show databases;

use project1;


create table author(
aid int NOT NULL,
aName varchar(32),
primary key (aid));


create table orderr(
OID int NOT NULL AUTO_INCREMENT ,
totalePrice real,
primary key (OID));

set foreign_key_checks = 0; 
alter table orderr auto_increment = 1;
alter table orderr modify column OID int not null auto_increment ;
set foreign_key_checks = 1;

create table oderline(
olid int NOT NULL AUTO_INCREMENT,
OID int,
quantity varchar(32),
primary key (olid),
foreign key (OID) references orderr(OID));

set foreign_key_checks = 0;
alter table oderline auto_increment = 1;
alter table oderline modify column olid int not null auto_increment ;
set foreign_key_checks = 1;

 create table customer(
 cID int NOT NULL ,
 cPhone int ,
 CAdrress varchar(32),
 cName varchar(32),
 OID int,
 primary key (cID),
 foreign key (OID) references orderr(OID));
 
 
 create table book(
 bID int NOT NULL,
 aid int ,
 olid int ,
 cID int,
 bName varchar(32),
bAuthor varchar(32),
bPrice int,
primary key(bID),
foreign key (aid) references author(aid),
foreign key (olid) references oderline (olid),
foreign key (cID) references customer(cID));

set foreign_key_checks = 0;
alter table book auto_increment = 1000;
alter table book modify column bID int not null auto_increment ;
set foreign_key_checks = 1;



create table calssification ( 
cid int NOT NULL  ,
typee varchar(32),
primary key (cid)
);

create table Bookandcalssification (
bid int,
cid int,
primary key (bid,cid),
foreign key (bid) references book(bid),
foreign key (cid) references calssification(cid));

create table office (
oNumber int NOT NULL,
oName varchar(32),
primary key (oNumber));

create table employee (
eid int NOT NULL ,
oNumber int,
eName varchar(32),
ePhone int,
eDepartment varchar(32),
primary key (eid),
foreign key (oNumber) references office(oNumber));

select * from employee ;

create table officeandcustomer (
oNumber int,
cID int,
primary key (oNumber,cid),
foreign key (oNumber) references office(oNumber),
foreign key (cID) references customer(cID));
 
 select * from author;
 insert into author values ( 0092586,"Ahmad Khaled ");
insert into author values ( 0072852,"Mohammad Saleh ");

select * from book;
set foreign_key_checks = 0;
SET GLOBAL FOREIGN_KEY_CHECKS=0;

insert into book(bID,aid, olid,cID, bname, bAuthor , bPrice)
 values (1,0092586,1 ,1191365, "English", "Ahmad Khale", 80);
 
 insert into book(bID,aid, olid,cID, bname, bAuthor , bPrice)
 values (2,0072852,2 ,1192658, "Math","Salem Saeed", 50);
 
  select * from calssification;
insert into calssification values ( 1191365,"Scientific");
insert into calssification values ( 1192658,"Scientific");

 select * from customer;
insert into customer values ( 1191365, 0569159842,"Ramallah" , "Noor Naje",1 );
insert into customer values ( 1192658, 0598723654,"Nablus", "Amal Nafez", 2 );


 select * from employee;
insert into employee values ( 11134, 2,"Mahmou Ghaith",0569385946, "Administration" );
insert into employee values ( 11235, 5, "Hamed Eid",0598721982, "Public services" );

 select * from orderr;
insert into orderr values ( 1, 80 );
insert into orderr values ( 2, 50 );

select * from oderline;
insert into oderline values ( 1, 1, 1 );
insert into oderline values ( 2, 2, 1);

 select * from office;
insert into office values ( 2, "Administration" );
insert into office values ( 5, "Public services" );